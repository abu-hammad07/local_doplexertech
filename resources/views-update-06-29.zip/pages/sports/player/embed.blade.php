<div class="embed-responsive embed-responsive-16by9 ratio ratio-16x9">
	 {!! $sports_info->video_url!!}
</div>
