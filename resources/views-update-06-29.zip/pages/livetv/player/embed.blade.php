<div class="origin-video-tag embed-responsive embed-responsive-16by9 ratio ratio-16x9 d-none">
	 {!! $tv_info->channel_url!!}
</div>
